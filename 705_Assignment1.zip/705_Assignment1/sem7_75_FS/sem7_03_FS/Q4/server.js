const express = require('express');
const WebSocket = require('ws');
const path = require('path');
const ChatBot = require('./chatbot');


const app = express();
const PORT = process.env.PORT || 3000;


app.use(express.static(path.join(__dirname, 'public')));


const server = app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});


const wss = new WebSocket.Server({ server });


const bot = new ChatBot();

wss.on('connection', (ws) => {
  console.log('New client connected');


  ws.on('message', (message) => {
    console.log(`Received message: ${message}`);


    const response = bot.getResponse(message);


    ws.send(response);
  });


  ws.on('close', () => {
    console.log('Client disconnected');
  });
});
