const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

/**

 * @param {string} sourceDir 
 * @param {string} outPath 
 */
function zipFolder(sourceDir, outPath) {

    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', {
        zlib: { level: 9 } 
    });

    output.on('close', () => {
        console.log(`Archive created successfully: ${archive.pointer()} total bytes.`);
    });

    archive.on('error', (err) => {
        throw err;
    });


    archive.pipe(output);


    archive.directory(sourceDir, false);


    archive.finalize();
}

const folderToZip = path.join(__dirname, 'folder-to-zip'); 
const zipFilePath = path.join(__dirname, 'hello.zip'); 

zipFolder(folderToZip, zipFilePath);
