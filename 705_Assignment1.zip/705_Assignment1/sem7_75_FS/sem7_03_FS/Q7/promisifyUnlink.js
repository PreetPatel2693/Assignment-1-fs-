const fs = require('fs');
const util = require('util');


const unlinkAsync = util.promisify(fs.unlink);

/**

 * @param {string} filePath 
 */
async function deleteFile(filePath) {
    try {
        await unlinkAsync(filePath);
        console.log(`File deleted successfully: ${filePath}`);
    } catch (err) {
        console.error(`Error deleting file: ${err.message}`);
    }
}


const filePath = 'file-to-delete.txt'; 


fs.writeFileSync(filePath, 'This file will be deleted.');


deleteFile(filePath);
