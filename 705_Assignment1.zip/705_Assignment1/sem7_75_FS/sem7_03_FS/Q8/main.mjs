import fetch from 'node-fetch';

async function callfunc() {
    fetch('https://google.com')
        .then(res => res.text())
        .then(text => printData(text))
        .catch(err => console.error('Error:', err));
}

callfunc();

function printData(res) {
    console.log(res);
}

