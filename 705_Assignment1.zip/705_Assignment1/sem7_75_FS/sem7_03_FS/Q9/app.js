const mongoose = require('mongoose');
const Employee = require('./employee');


const dbConfig = 'mongodb://localhost:27017/company'; 

async function insertEmployee(name, position, salary) {
    try {
        const employee = new Employee({ name, position, salary });
        const result = await employee.save();
        console.log(`Inserted employee with ID: ${result._id}`);
    } catch (error) {
        console.error('Error inserting employee:', error.message);
    }
}


async function displayEmployees() {
    try {
        const employees = await Employee.find();
        console.log('Employee Records:');
        console.table(employees); 
    } catch (error) {
        console.error('Error fetching employees:', error.message);
    }
}

(async () => {
 
    await mongoose.connect(dbConfig, { useNewUrlParser: true, useUnifiedTopology: true });

   
    await insertEmployee('Aditya', 'Software Engineer', 5000);
    await displayEmployees();

   
    mongoose.connection.close();
})();
